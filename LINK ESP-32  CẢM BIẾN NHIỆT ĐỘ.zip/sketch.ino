
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <DHT.h>

// Khai bao LCD I2C
LiquidCrystal_I2C lcd(0x27, 16, 2);

// Khai bao DHT22
#define DHTPIN 4
#define DHTTYPE DHT22
DHT dht(DHTPIN, DHTTYPE);

void setup() {
  Serial.begin(115200);

  // Khoi dong LCD
  Wire.begin(21, 22);
  lcd.init();
  lcd.backlight();

  // Khoi dong DHT22
  dht.begin();

  lcd.setCursor(0, 0);
  lcd.print("ESP32 SYSTEM");
  lcd.setCursor(0, 1);
  lcd.print("Starting...");
  delay(2000);
  lcd.clear();
}

void loop() {
  float h = dht.readHumidity();
  float t = dht.readTemperature();

  lcd.setCursor(0, 0);
  lcd.print("Nhiet do: ");

  if (isnan(t) || isnan(h)) {
    lcd.setCursor(0, 1);
    lcd.print("DHT22 Error     ");
  } else {
    lcd.print(t, 1);
    lcd.print((char)223);
    lcd.print("C ");

    lcd.setCursor(0, 1);
    lcd.print("Do am: ");
    lcd.print(h, 1);
    lcd.print("%    ");
  }

  delay(2000);
}
